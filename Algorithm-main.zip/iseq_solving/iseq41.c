#include <stdio.h>
#include <stdlib.h>

struct list{
	char name[50];
	int grade;
	int rank;
};

int main(void)
{
	int num;
	int max = 0;
	scanf("%d", &num);

	struct list *line = malloc(sizeof(struct list) * num);
	
	for (int i = 0; i < num; i++) {
		scanf("%s", line[i].name);
		scanf("%d", &line[i].grade);
	}


	for (int i = 0; i < num; i++) { //��� ���ϴ� ����
		int rank = 1;
		for (int j = 0; j < num; j++)
			if (line[i].grade < line[j].grade)
				rank++;

		printf("%s %d\n", line[i].name, rank);
	}

	free(line);

	return 0;
}