#include <stdio.h>
#include <stdlib.h>

struct list{
	char name[50];
	int grade;
};

int main(void)
{
	int num;
	int max = 0;
	scanf("%d", &num);

	struct list *line = malloc(sizeof(struct list) * num);
	
	for (int i = 0; i < num; i++) {
		scanf("%s", line[i].name);
		scanf("%d", &line[i].grade);
	}

	for (int p = 0; p < num; p++) {
		for (int q = 0; q < num; q++) {
			if (line[q].grade > max){
				max = line[q].grade;
			}
		}
		if (line[p].grade == max); {
			//printf("[%d] ", line[p].grade);
			line[p].grade = p;

		}
	}

	for (int i = 0; i < num; i++) {
		printf("%s", line[i].name);
		printf("%d\n", line[i].grade);
	}


	free(line);

	return 0;
}