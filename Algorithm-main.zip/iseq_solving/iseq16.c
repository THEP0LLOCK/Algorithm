#include <stdio.h>

int main(void)
{
	char str[100];
	scanf("%s", str);
	printf("%c %d", str[2], str[2]);



}