#include <stdio.h>
int main(void)
{
	int c;
	int array[20];
	scanf("%d", &c);
	for (int i = 0; i < c; i++) {
		scanf("%d", &array[i]);
	}
	for (int k = 0;k < c; k++){
		for (int i = 0; i < c-1; i++) {
			if (array[i] > array[i + 1]){
				int tmp;
				tmp = array[i];
				array[i] = array[i + 1];
				array[i + 1] = tmp;
			}
		}
	}
	for (int i = 0; i < c; i++) {
		printf("%d ", array[i]);
	}




	return 0;
}