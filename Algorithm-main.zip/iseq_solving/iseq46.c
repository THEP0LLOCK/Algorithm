#include <stdio.h>
#include <string.h>
int main(void)
{
	char str[100];
	char str1[100];
	char str2[100];
	scanf("%s", str);
	int i,c=0;
	for (i = 0; i < strlen(str); i++) {
		if (str[i] == '@') {
			break;
		}
		else str1[i] = str[i];
	}
	str1[i] = 0;
	for (i=i+1; i < strlen(str); i++) {
		str2[c] = str[i];
		c++;
	}
	str2[c] = 0;
	printf("%s@%s", str2,str1);
}