#include <stdio.h>
int main(void)
{
	int a1;
	scanf("%d", &a1);
	int a2;
	scanf("%d", &a2);
	int a3;
	scanf("%d", &a3);
	int a4;
	scanf("%d", &a4);
	int a5;
	scanf("%d", &a5);
	for (int i = 0; i < a1; i++) {
		printf("*");
	}
	printf("\n");
	for (int i = 0; i < a2; i++) {
		printf("*");
	}
	printf("\n");
	for (int i = 0; i < a3; i++) {
		printf("*");
	}
	printf("\n");
	for (int i = 0; i < a4; i++) {
		printf("*");
	}
	printf("\n");
	for (int i = 0; i < a5; i++) {
		printf("*");
	}
	printf("\n");


	return 0;
}