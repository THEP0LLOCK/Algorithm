#include <stdio.h>
int main(void)
{
	int array[10];
	int i = 0;
	while(scanf("%d", array[i]) != 0) {
		scanf("%d", array[i]);
		i++;
	}
	while (scanf("%d", array[i]) != 0) {
		scanf("%d", array[i]);
		i++;
	}
}