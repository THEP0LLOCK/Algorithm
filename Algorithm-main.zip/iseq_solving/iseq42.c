#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	srand(time(NULL));
	int random = 0;
	int r;
	double a[6] = { 0 };

	scanf("%d", &r);

	for (int i = 0; i < r; i++) {
		a[rand() % 6]++;
	}
	for (int j = 0; j < 6; j++) {
		printf("%d %.0f %.2lf\n", j + 1, a[j], a[j] / r * 100);


	}


	return 0;
}