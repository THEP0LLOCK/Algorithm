#include <stdio.h>
int main(void)
{
	int num;
	scanf("%d", &num);
	int array[20][30] = { 0 };
	array[0][num-1] = 1;
	for (int i = 0; i < num; i++) {
		for (int j = 0; j < num*2; j++) {
			if (array[i][j] > 0) {
				array[i + 1][j - 1] += array[i][j];
				array[i + 1][j + 1] += array[i][j];
			}
		
		}
	}


	for (int i = 0; i < num; i++) {
		for (int j = 0; j < num * 2; j++) {
			if (array[i][j] == 0) printf(" ");
			else printf("%d", array[i][j]);
		}
		printf("\n");
	}
	//000010000
	//000101000
	//001020100
	//010302000
}