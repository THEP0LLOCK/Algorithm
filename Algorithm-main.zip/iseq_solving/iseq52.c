#include <stdio.h>
int main(void)
{
	int r;
	int num;
	scanf("%d", &num);


	for (r = 1; r < num; r++) {
		for (int i = 0; i < r;i++) printf("%d", i);
	}




}