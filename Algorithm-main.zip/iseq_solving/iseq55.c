#include <stdio.h>
int main(void)
{
	int num;
	int array[20] = { 0 };
	array[0] = 1;
	array[1] = 1;
	scanf("%d", &num);
	for (int i = 0; i < num; i++) {
		array[i + 2] = array[i] + array[i+1];
	}

	printf("%d", array[num-1]);




}