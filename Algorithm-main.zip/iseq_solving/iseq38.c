#include <stdio.h>
int main(void)
{
	double type[2] = { 20,10 };
	int destination[6] = { 5500,7000,8500,9500,12000,20000 };
	
	int a1 = 1, a2 = 1, a3 = 1;
	int price = 0;

	while (1){

		if (a1 == 0 & a2 == 0 & a3 == 0) {
			break;
		}
		else {
			scanf("%d %d %d", &a1, &a2, &a3);
			printf("%.0lf\n", destination[a2 - 1] * (100 - type[a1 - 1]) / 100 * a3);
		}
	}




	return 0;
}