#include <stdio.h>
int main(void)
{
	int num;
	int r2,r=1,p=1;
	
	scanf("%d", &num);
	r2 = num;
	int array[10][10];

	int x = -1, y = 0;
	while (r <= num * num){
		for (int i = 0; i < r2; i++) { //*5
			x+=p;
			array[y][x] = r++;
			
		}
	
		for (int i = 0; i < r2-1; i++) { //*5
			y+=p;
			array[y][x] = r++;
			
		}
		r2--;
		p *= -1;
	}
	for (int i = 0; i < num; i++) {
		for (int p = 0; p < num; p++) {
			if (array[i][p] < 10)printf("%d  ", array[i][p]);
			else printf("%d ", array[i][p]);
		}
		printf("\n");
	}
	return 0;
}