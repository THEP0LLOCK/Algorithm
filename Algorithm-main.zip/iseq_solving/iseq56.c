#include <stdio.h>
int main(void)
{

	for (int i = 0; i < 999; i++) {
		int a = i % 10;
		int b = (i % 100 - i % 10) / 10;
		int c = i / 100;
		if (a*a*a+b*b*b+c*c*c == i) printf("%d\n", i);
	}
	/*
	int i = 153;
	int a = i % 10;
	int b = (i % 100 - i % 10) / 10;
	int c = i / 100;
	printf("%d\n", a * a * a + b * b * b + c * c * c);
	printf("%d %d %d", a, b, c);
	*/
}
