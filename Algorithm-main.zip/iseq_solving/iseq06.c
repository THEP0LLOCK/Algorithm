#include <stdio.h>
int main(void)
{
	int x;
	scanf("%d", &x);
	printf("%d", (x/3)*4);

	return 0;
}