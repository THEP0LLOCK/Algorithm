#include <stdio.h>
int main(void)
{
	int array[10] = { 'Y','B','K','E','A','R','N','D','O','G' };
	int num;
	int a1, a2, a3, a4;
	scanf("%d", &num);

	a1 = num / 1000; //9
	a2 = num / 100 - 10 * a1; //8
	a3 = (num - num / 100 * 100 )/ 10; //8
	a4 = (num - num / 100 * 100) - 10*a3;
	printf("%c", array[a1]);
	printf("%c", array[a2]);
	printf("%c", array[a3]);
	printf("%c", array[a4]);




}