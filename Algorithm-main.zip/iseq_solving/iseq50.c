#include <stdio.h>
int main(void)
{
	int N;
	int r = 0;
	scanf("%d", &N);

	for (r = 0; r < N; r++){
		for (int i = 0; i < N - r; i++) printf(" ");
		for (int i = 0; i < r; i++) printf("%d", i + 1);
		for (int i = r; i > -1; i--) printf("%d", i + 1);
		printf("\n");
	}

	/*
		�Է� : 5
	        1        4:1:4
	       121       3:3:3
		  12321      2:5:2
		 1234321     1:7:1
		123454321    0:9:0
	*/
}