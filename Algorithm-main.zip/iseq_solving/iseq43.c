#include <stdio.h>
#include <string.h>
int main(void)
{
	char str[100];
	char tmp;
	scanf("%s", str);
	for (int i = 0; i < strlen(str)/2; i++) {
		tmp = str[i];
		str[i] = str[strlen(str) - i - 1];
		str[strlen(str) - i - 1] = tmp;
	}
	printf("%s", str);
}