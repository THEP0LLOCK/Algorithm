#include <stdio.h>
int main(void)
{
	int num;
	int r2,r=1;
	
	scanf("%d", &num);
	r2 = num;
	int array[10][10];

	int x = 0, y = 0;
	while(r<=num*num){
		for (int i = 0; i < r2; i++) { //*5
			array[y][x] = r++;
			x++;
		}
	r2--;
		for (int i = 0; i < r2; i++) { //*5
			array[y][x] = r++;
			y++;
		}
	}

}