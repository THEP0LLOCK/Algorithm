#include <stdio.h>
int main(void)
{
	int n,s=1,t=1;
	int array[150] = { 0 };
	scanf("%d", &n);

	array[0] = 1;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < s; j++) {
			array[j] *= 2;
		}
		for (int j = 0; j < s; j++) {
			if (array[j] > 9) {
				array[j + 1] += array[j] / 10;
				array[j] %= 10;
				if (j + 1 == s) {
					s++;
				}
			}
		}
	}
	for (int i = s-1; i >= 0; i--) {
		printf("%d", array[i]);
	}
}