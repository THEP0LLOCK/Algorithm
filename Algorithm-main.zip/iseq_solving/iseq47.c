#include <stdio.h>
#include <string.h>
int main(void)
{
	char str[100];
	char selector[2];
	int num;
	scanf("%s", str);
	scanf("%s", &selector);
	scanf("%d", &num);

	for (int i = 0; i < strlen(str); i++) {
		if (selector == 'R'){
			if (str[i + num] != 0){
				printf("%c", str[i + num]);
			}
			else {
				for (int i = 0; i < num; i++) {
					printf("%c", str[i]);
				}
			}
		}
	}
}