#include <stdio.h>
int main(void)
{
	int n,i = 0;
	int array[100];
	scanf("%d", &n);
	while(n!=1){		
		array[i] = n%2;
		n = n / 2;
		i++;
	}
	array[i] = 1;
	for (int l = i; l != -1; l--) printf("%d", array[l]);


}