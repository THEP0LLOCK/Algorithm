#include <stdio.h>
int main(void) {
	int t;
	scanf("%d", &t);
	int array[10][10];

	//������Ʈ
	for (int x = 0; x < t; x++) {
		for (int y = 0; y < t; y++) {
			array[x][y] = ("%d", t * (t - y) - x);
		}
	}

	//�����Ʈ
	for (int x = 0; x < t; x++) {
		for (int y = 0; y < t; y++) {
			printf("%3d", array[x][y]);
		}
		printf("\n");
	}

	return 0;






/*#include <stdio.h>
	int main(void) {
		int num;
		int i;
		scanf("%d", &num);
		int array[10][10];

		for (i = 0; i < num * num; i++) {
			array[i / num][i % num] = i + 1;
		}
		//���
		for (int x = 0; x < num; x++) {
			for (int y = 0; y < num; y++) {
				printf("%3d", array[x][y]);
			}
			printf("\n");
		}

		return 0;
	}
	*/



}