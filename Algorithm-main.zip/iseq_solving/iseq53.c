#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(void)
{
	int num;
	scanf("%d", &num);
	int array[10][10] = { 0 };
	int x = num / 2, y = 0;
	for (int i = 1; i <= num*num; i++) {
		array[y % num][x % num] = i;
		if (i % num == 0)
			y++;
		else {
			x++;
			y--;
		}
		
		if (y < 0) {
			y = num - 1;
		}
	}
	for (int i = 0; i < num * num; i++) {
		if (i >= num - 1 && i % num == 0) printf("\n");
		printf("%d", array[i/num][i%num]);

	}


}