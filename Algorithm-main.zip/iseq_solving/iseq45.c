#include <stdio.h>
#include <string.h>
#include <string.h>
int main(void) {
	//A=65 a=97 => +32
	char str[100];

	gets_s(str, 99);
	for (int i = 0; i < strlen(str); i++) {
		if ('a' <= str[i] && str[i] <= 'z') {
			printf("%c", str[i] - ('a' - 'A'));
		}
		else if ('A' <= str[i] && str[i] <= 'Z') {
			printf("%c", str[i] + ('a' - 'A'));
		}
		else
			printf("%c", str[i]);
	}
}