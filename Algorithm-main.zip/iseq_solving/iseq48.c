#include <stdio.h>
#include <string.h>
int main(void) {
	int tmp = 1;
	char str[100];
	char fianl[100];
	char selector;
	scanf("%s", str);
	for (int i = 0; i < strlen(str); i++) {
		
		if (str[i] == str[i + 1]) {
			tmp++;
			selector = str[i];
		}
		else {
			if (tmp >= 5){
				printf("%c", selector);
				printf("(%d)",tmp);
			}
			else for (int j = 0; j < tmp; j++) printf("%c", selector);
			tmp = 1;
		}
	}



}